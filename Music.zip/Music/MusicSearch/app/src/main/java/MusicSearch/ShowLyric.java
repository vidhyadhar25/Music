package MusicSearch;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.*;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.gandhi.musicsearch.R;

import java.net.URLEncoder;


public class ShowLyric extends Activity {

    TextView txtLyrics;
    String artistName, trackName;
    private RequestQueue mVolleyQueue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lyrics);

        txtLyrics = (TextView) findViewById(R.id.txtLyrics);

        if (getIntent().hasExtra("artistName")) {
            artistName = getIntent().getStringExtra("artistName");
            trackName = getIntent().getStringExtra("trackName");
        }

        mVolleyQueue = Volley.newRequestQueue(this);
         showProgress();
        FindLyricsForQuery(trackName, artistName);
    }

    /**
     * method to find the lyrics on basis of trackname
     * and artist name
     * @param trackName
     * @param artistName
     */
    private void FindLyricsForQuery(final String trackName, String artistName) {
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, "http://lyrics.wikia.com/api.php?artist="+ URLEncoder.encode(artistName)+"&song="+URLEncoder.encode(trackName)+"&fmt=xml",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String jsonObject) {
                        if (jsonObject.contains("<lyrics>")) {
                            String result = jsonObject.substring(jsonObject.indexOf("<lyrics>") + 8, jsonObject.indexOf("</lyrics>"));
                            txtLyrics.setText(result);
                        }else {
                            Toast.makeText(ShowLyric.this, "No lryics found", 1).show();
                        }
                       stopProgress();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
               stopProgress();
            }
        });

        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(5000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mVolleyQueue.add(jsonObjectRequest);
    }


    private ProgressDialog mProgress;
    private void showProgress() {
        mProgress = ProgressDialog.show(this, "", "Loading...");
    }

    private void stopProgress() {
        mProgress.cancel();
    }

}
