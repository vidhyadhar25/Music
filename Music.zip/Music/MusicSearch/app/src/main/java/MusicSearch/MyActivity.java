package MusicSearch;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.gandhi.musicsearch.R;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import MusicSearch.model.Result;
import MusicSearch.model.SearchData;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

    private RequestQueue mVolleyQueue;
    private ListView mListView;
    private EfficientAdapter mAdapter;
    private ProgressDialog mProgress;
    private List<Result> mDataList;

    private EditText etSearch;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        etSearch = (EditText) findViewById(R.id.etSearch);
        mListView = (ListView) findViewById(R.id.image_list);

        mDataList = new ArrayList<Result>();
        mAdapter = new EfficientAdapter(this);
        mListView.setAdapter(mAdapter);
        mVolleyQueue = Volley.newRequestQueue(this);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Result result = mDataList.get(position);
                Intent intent = new Intent(MyActivity.this,ShowLyric.class);
                intent.putExtra("artistName", result.getArtistName());
                intent.putExtra("trackName", result.getTrackName());
                startActivity(intent);
            }
        });
    }

    /**
     * on click for search button
     * @param view
     */
    public void OnSearchClick(View view){
        String search = etSearch.getText().toString();
        if (TextUtils.isEmpty(search)){
            Toast.makeText(MyActivity.this, "please enter search query",1).show();
            return;
        }
        showProgress();
        SearchThisTerm(search);
    }


    /**
     * the method to search on apple api
     * @param search
     */
    private void SearchThisTerm(String search) {

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, "https://itunes.apple.com/search?term=" + search, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                Gson gson = new Gson();
                SearchData searchData = gson.fromJson(jsonObject.toString(), SearchData.class);
                if (searchData!=null && searchData.getResultCount()>0) {
                    mDataList.clear();
                    mDataList = searchData.getResults();
                    mAdapter.notifyDataSetChanged();
                }else {
                    Toast.makeText(MyActivity.this, "No data found",1).show();
                }
                stopProgress();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.d("search","error");
                stopProgress();
            }
        });

        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(5000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mVolleyQueue.add(jsonObjectRequest);
    }


    private void showProgress() {
        mProgress = ProgressDialog.show(this, "", "Loading...");
    }

    private void stopProgress() {
        mProgress.cancel();
    }

    private class EfficientAdapter extends BaseAdapter {

        private LayoutInflater mInflater;

        public EfficientAdapter(Context context) {
            mInflater = LayoutInflater.from(context);
        }

        public int getCount() {
            return mDataList.size();
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.list_item, null);
                holder = new ViewHolder();
                holder.image = (ImageView) convertView.findViewById(R.id.image);
                holder.trackName = (TextView) convertView.findViewById(R.id.trackName);
                holder.artistName = (TextView) convertView.findViewById(R.id.artistName);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            holder.artistName.setText(mDataList.get(position).getArtistName());
            holder.trackName.setText(mDataList.get(position).getTrackName());
            Picasso.with(MyActivity.this).load(mDataList.get(position).getArtworkUrl100()).into(holder.image);
            return convertView;
        }

        class ViewHolder {
            TextView artistName,trackName;
            ImageView image;
        }

    }
}
